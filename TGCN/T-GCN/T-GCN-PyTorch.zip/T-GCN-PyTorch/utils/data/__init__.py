from utils.data.spatiotemporal_csv_data import SpatioTemporalCSVDataModule


SupervisedDataModule = SpatioTemporalCSVDataModule


__all__ = [
    "SupervisedDataModule",
    "SpatioTemporalCSVDataModule",
]
