from tasks.supervised import SupervisedForecastTask


__all__ = ["SupervisedForecastTask"]
